@extends('views.master')
@section('title','Layout template')
@section('content')
    Đây là trang layout
@stop