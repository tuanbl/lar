<?php $__env->startSection('sidebar'); ?>

    <p>This is sub blade </p>
    ##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title','sub template'); ?>
<?php $__env->startSection('content'); ?>
    Đây là trang sub<br>
    <?php
        $hoten = "<br>Nguyễn Văn Tèo";
        $diem = 9;
    ?>
    <?php echo e($hoten); ?>

    <?php echo $hoten; ?>

    <?php if($diem<=5): ?>
        Học sinh Yếu
    <?php elseif($diem >5 && $diem <=7): ?>
        Học sinh Trung bình
    <?php else: ?>
        Học sinh giỏi
    <?php endif; ?>
    </br>
    <?php echo e(!isset($diem) ? $diem : "Không tồn tại điệm"); ?>

    <br>

    <?php echo e(isset($diemm) ? $diemm : 'Không tồn tại biến điểm'); ?>

    <br>

    <?php for($i=0;$i<10;$i++): ?>
        So thứ tự: <?php echo $i; ?> <br>
    <?php endfor; ?>
    <br><br>
        <hr/>
        <?php
             $i=0;
        ?>
    <?php while($i<10): ?>
    Số thứ nự <?php echo e($i); ?><br>
    <?php
        $i++;
    ?>

    <?php endwhile; ?>
    <hr>
    <?php
        $array = ['com','chao','canh'];

    ?>
    <?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        hôm nay ăn <?php echo e($k); ?>:<?php echo e($v); ?><br>


    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        








<?php $__env->stopSection(); ?>
<?php echo $__env->make('views.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('views.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>